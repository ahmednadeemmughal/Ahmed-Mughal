import React from 'react';
import { motion } from 'framer-motion';
import ScrollStack, { ScrollStackItem } from './ScrollStack';

interface Project { number: string; title: string; category: string; description: string; githubUrl: string; tech: string[]; metrics: { label: string; value: string }[]; }

const github = 'https://github.com/ahmednadeemmughal';
const projects: Project[] = [
  { number: '01', title: 'Jarvis AI Assistant', category: 'AI / PYTHON / ANDROID', description: 'A personal voice assistant project built for Android with Python and Termux. It explores voice input, text-to-speech, app launching, web search and device automation.', githubUrl: github, tech: ['Python', 'Termux', 'Android', 'Voice UI', 'TTS'], metrics: [{ label: 'TYPE', value: 'Personal AI' }, { label: 'INPUT', value: 'Voice + Text' }, { label: 'PLATFORM', value: 'Android' }] },
  { number: '02', title: '16 LINE QURAN', category: 'ANDROID / KOTLIN', description: 'A native Android Quran application project focused on a traditional 16-line reading experience, Quran navigation, recitation, bookmarks, search and offline-first use.', githubUrl: `${github}/16-line-Quran`, tech: ['Kotlin', 'Android', 'Jetpack Compose', 'Quran UI'], metrics: [{ label: 'TYPE', value: 'Native Android' }, { label: 'FOCUS', value: 'Quran Reader' }, { label: 'STATUS', value: 'In Development' }] },
  { number: '03', title: 'AI STUDY PLANNER', category: 'AI / PRODUCTIVITY / WEB', description: 'A study productivity app designed to help students structure learning, plan sessions and experiment with AI-assisted study workflows.', githubUrl: `${github}/Study-planner-app`, tech: ['TypeScript', 'React', 'AI', 'Productivity'], metrics: [{ label: 'TYPE', value: 'Web App' }, { label: 'FOCUS', value: 'Study Tools' }, { label: 'STACK', value: 'TypeScript' }] },
  { number: '04', title: '3D PERIODIC TABLE', category: 'WEB / INTERACTIVE UI', description: 'An interactive chemistry experience combining a modern periodic table layout with responsive controls and 3D visual effects.', githubUrl: `${github}/Periodic-table-`, tech: ['HTML', 'CSS', 'JavaScript', '3D UI'], metrics: [{ label: 'TYPE', value: 'Interactive Web' }, { label: 'SUBJECT', value: 'Chemistry' }, { label: 'STYLE', value: '3D / Motion' }] },
  { number: '05', title: 'VIRTUAL STEERING GAME', category: 'GAME / COMPUTER VISION', description: 'An experimental driving game and virtual steering interface exploring gesture-based interaction and browser game mechanics.', githubUrl: `${github}/Virtual_steering_game`, tech: ['JavaScript', 'Game UI', 'Gestures', 'Web'], metrics: [{ label: 'TYPE', value: 'Browser Game' }, { label: 'INPUT', value: 'Virtual Steering' }, { label: 'FOCUS', value: 'Interaction' }] },
  { number: '06', title: 'CREATIVE WEB EXPERIMENTS', category: 'WEB / 3D / VFX', description: 'A collection of experimental visual projects including particles, hand-gesture effects, vanish effects and cinematic interfaces built while learning by making.', githubUrl: github, tech: ['JavaScript', '3D', 'VFX', 'Animation'], metrics: [{ label: 'TYPE', value: 'Experiments' }, { label: 'FOCUS', value: 'Visual UI' }, { label: 'MODE', value: 'Learn by Build' }] },
];

export const ProjectsSection: React.FC = () => (
  <section id="work" className="relative w-full bg-black text-[#E8DFD8] font-sans pt-20 pb-32 px-6 sm:px-12 lg:px-20">
    <div className="absolute top-1/4 left-1/3 w-[36rem] h-[36rem] bg-[#D4AF37]/5 rounded-full blur-[180px] pointer-events-none" />
    <div className="absolute bottom-1/4 right-1/4 w-[30rem] h-[30rem] bg-[#8C6D4F]/5 rounded-full blur-[170px] pointer-events-none" />
    <div className="max-w-7xl mx-auto w-full relative z-10">
      <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="flex items-center space-x-4 mb-5">
        <span className="text-[11px] font-medium tracking-[0.35em] uppercase text-[#D4AF37]" style={{ fontFamily: "'Montserrat', sans-serif" }}>02 / SELECTED WORK</span><div className="w-20 h-[1px] bg-gradient-to-r from-[#D4AF37]/80 via-[#8C6D4F]/40 to-transparent" />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.9 }} className="flex flex-col md:flex-row md:items-end justify-between mb-16">
        <h2 className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] tracking-tight uppercase leading-[0.85]" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>
          <span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#FFFFFF] via-[#D5CBC0] to-[#605448]">PROJECTS I BUILT.</span>
          <span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#F7E7C4] via-[#C99E5D] to-[#543B1A]">IDEAS MADE REAL.</span>
        </h2>
        <p className="text-xs sm:text-sm font-light text-[#A8988B] max-w-sm mt-4 md:mt-0 leading-relaxed" style={{ fontFamily: "'Montserrat', sans-serif" }}>A selection of apps, games, AI experiments and interactive websites built while learning through real projects.</p>
      </motion.div>

      <ScrollStack itemDistance={20} itemScale={0.035} itemStackDistance={28} stackPosition="15%" scaleEndPosition="6%" baseScale={0.88} useWindowScroll={true}>
        {projects.map((project) => (
          <ScrollStackItem key={project.title}>
            <div className="relative w-full rounded-2xl border border-[#8C6D4F]/50 bg-[#0E0C0A] p-8 sm:p-12 shadow-[0_25px_70px_rgba(0,0,0,0.98)] group overflow-hidden transition-colors duration-500 hover:border-[#D4AF37]">
              <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37]/80 to-transparent" />
              <span className="absolute -bottom-6 -right-3 text-8xl sm:text-9xl font-bold text-[#EAD8C7]/5 select-none pointer-events-none leading-none" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>{project.number}</span>
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
                <div className="lg:col-span-7 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center space-x-3 mb-4"><span className="text-xs font-mono font-bold text-[#D4AF37]">{project.number} //</span><span className="text-[10.5px] font-mono tracking-[0.25em] uppercase text-[#A8988B]">{project.category}</span></div>
                    <h3 className="text-4xl sm:text-5xl lg:text-6xl font-normal tracking-tight text-white mb-4 group-hover:text-[#F7E7C4] uppercase leading-[0.9]" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>{project.title}</h3>
                    <p className="text-xs sm:text-sm md:text-[14px] font-light text-[#BDB0A4] leading-[1.85] tracking-wide mb-8 max-w-2xl" style={{ fontFamily: "'Montserrat', sans-serif" }}>{project.description}</p>
                  </div>
                  <div className="flex flex-wrap gap-2 pt-6 border-t border-[#8C6D4F]/25">{project.tech.map((t) => <span key={t} className="px-3 py-1 text-[10px] font-medium tracking-[0.16em] uppercase rounded-sm border border-[#8C6D4F]/40 bg-[#16120E] text-[#E8D7C5] group-hover:border-[#D4AF37]/50" style={{ fontFamily: "'Montserrat', sans-serif" }}>{t}</span>)}</div>
                </div>
                <div className="lg:col-span-5 flex flex-col justify-between h-full space-y-6 lg:pl-6 lg:border-l lg:border-[#8C6D4F]/25">
                  <div className="space-y-3"><span className="text-[9.5px] font-mono tracking-[0.25em] uppercase text-[#8C6D4F] block mb-2">// PROJECT DETAILS</span>{project.metrics.map((m) => <div key={m.label} className="p-3.5 rounded-sm border border-[#8C6D4F]/25 bg-[#050403] flex items-center justify-between"><span className="text-[10px] font-mono text-[#A8988B]">{m.label}</span><span className="text-[11px] font-mono font-medium text-[#F7E7C4]">{m.value}</span></div>)}</div>
                  <a href={project.githubUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center space-x-3 px-6 py-3.5 border border-[#8C6D4F] bg-[#16120E] hover:border-[#D4AF37] hover:bg-[#D4AF37] text-[#EAD8C7] hover:text-black text-[11px] font-medium tracking-[0.24em] uppercase transition-all duration-300" style={{ fontFamily: "'Montserrat', sans-serif" }}> <span>VIEW ON GITHUB</span><span>↗</span></a>
                </div>
              </div>
            </div>
          </ScrollStackItem>
        ))}
      </ScrollStack>
    </div>
  </section>
);

export default ProjectsSection;
