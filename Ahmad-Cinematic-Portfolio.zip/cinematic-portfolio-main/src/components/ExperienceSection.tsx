import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

interface RouteStop { id: string; year: string; title: string; organization: string; description: string; }
const journey: RouteStop[] = [
  { id: '01', year: '2026', title: 'BUILDING WITH AI', organization: 'AI + WEB DEVELOPMENT', description: 'Exploring AI-powered products, coding assistants and app builders while learning how to turn ideas into working software.' },
  { id: '02', year: '2026', title: 'JARVIS PROJECT', organization: 'PYTHON + TERMUX + ANDROID', description: 'Building a personal voice assistant for Android with speech input, text-to-speech, app launching, search and device interactions.' },
  { id: '03', year: '2026', title: 'NATIVE ANDROID', organization: '16 LINE QURAN', description: 'Working toward a native Quran reading application with a 16-line Mushaf experience and features designed around reading and recitation.' },
  { id: '04', year: '2026', title: 'WEB & GAME EXPERIMENTS', organization: 'GITHUB PROJECTS', description: 'Creating study tools, interactive periodic tables, browser games, particle experiments, VFX projects and responsive websites.' },
  { id: '05', year: 'ONGOING', title: 'LEARN BY BUILDING', organization: 'PERSONAL DEVELOPMENT', description: 'Continuously learning programming, AI and product development by shipping small projects, testing ideas and improving existing work.' },
];

export const ExperienceSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef, offset: ['start 70%', 'end 90%'] });
  const lineHeight = useTransform(scrollYProgress, [0, 1], ['0%', '100%']);

  return (
    <section id="experience" ref={containerRef} className="relative w-full bg-black text-[#E8DFD8] font-sans pt-4 pb-24 px-6 sm:px-12 lg:px-20 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-[40rem] bg-[#D4AF37]/[0.03] rounded-full blur-[150px] pointer-events-none" />
      <div className="max-w-4xl mx-auto w-full relative z-10">
        <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="flex items-center space-x-4 mb-7"><span className="text-[11px] font-medium tracking-[0.35em] uppercase text-[#D4AF37]" style={{ fontFamily: "'Montserrat', sans-serif" }}>04 / MY JOURNEY</span><div className="w-20 h-[1px] bg-gradient-to-r from-[#D4AF37]/80 via-[#8C6D4F]/40 to-transparent" /></motion.div>
        <motion.div initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.9 }} className="mb-16"><h2 className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] tracking-tight uppercase leading-[0.85]" style={{ fontFamily: "'Bebas Neue', sans-serif" }}><span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#FFFFFF] via-[#D5CBC0] to-[#605448]">BUILDING IN PUBLIC.</span><span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#F7E7C4] via-[#C99E5D] to-[#543B1A]">ONE PROJECT AT A TIME.</span></h2></motion.div>
        <div className="relative w-full"><div className="absolute left-[19px] md:left-[140px] top-4 bottom-8 w-[1px] bg-[#8C6D4F]/20" /><motion.div style={{ height: lineHeight }} className="absolute left-[19px] md:left-[140px] top-4 w-[2px] bg-gradient-to-b from-[#D4AF37] via-[#C99E5D] to-[#8C6D4F]/10 shadow-[0_0_10px_#D4AF37] origin-top" /><div className="space-y-12">{journey.map((stop, idx) => <motion.div key={stop.id} initial={{ opacity: 0, x: -15 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true, margin: '-50px' }} transition={{ duration: 0.7, delay: idx * 0.08 }} className="relative flex flex-col md:flex-row items-start group"><div className="hidden md:block w-[140px] shrink-0 pr-8 pt-0.5 text-right"><span className="text-[10px] font-mono tracking-[0.2em] text-[#8C6D4F] group-hover:text-[#D4AF37]">{stop.year}</span></div><div className="absolute left-[19px] md:left-[140px] top-1.5 -translate-x-1/2"><div className="w-2.5 h-2.5 rounded-full bg-[#120F0C] border border-[#8C6D4F] group-hover:bg-[#D4AF37] group-hover:border-[#D4AF37] group-hover:shadow-[0_0_12px_#D4AF37] transition-colors" /></div><div className="ml-14 md:ml-12 pl-2"><div className="md:hidden mb-1.5"><span className="text-[10px] font-mono tracking-[0.2em] text-[#D4AF37]">{stop.year}</span></div><h3 className="text-3xl sm:text-4xl tracking-wide text-white group-hover:text-[#F7E7C4] mb-1 leading-none" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>{stop.title}</h3><span className="block text-[10px] font-medium tracking-[0.2em] uppercase text-[#8C6D4F] mb-2" style={{ fontFamily: "'Montserrat', sans-serif" }}>{stop.organization}</span><p className="text-xs sm:text-[13px] font-light text-[#A8988B] leading-[1.7] max-w-lg" style={{ fontFamily: "'Montserrat', sans-serif" }}>{stop.description}</p></div></motion.div>)}</div></div>
      </div>
    </section>
  );
};
export default ExperienceSection;
