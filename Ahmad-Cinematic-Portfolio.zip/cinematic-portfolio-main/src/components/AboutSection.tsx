import React, { useRef, useState } from 'react';
import { motion, useMotionValue, useTransform, useSpring } from 'framer-motion';
import type { Variants } from 'framer-motion';
import aboutImg from '../assets/about.png';

const containerVariants: Variants = { hidden: { opacity: 0 }, visible: { opacity: 1, transition: { staggerChildren: 0.18, delayChildren: 0.15 } } };
const fadeUpVariants: Variants = { hidden: { opacity: 0, y: 30, filter: 'blur(10px)' }, visible: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 1.2, ease: [0.16, 1, 0.3, 1] } } };

export const AboutSection: React.FC = () => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isCardHovered, setIsCardHovered] = useState(false);
  const mouseX = useMotionValue(0), mouseY = useMotionValue(0), spotlightX = useMotionValue(200), spotlightY = useMotionValue(200);
  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [16, -16]), { damping: 18, stiffness: 220 });
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-16, 16]), { damping: 18, stiffness: 220 });
  const spotlightBg = useTransform([spotlightX, spotlightY], ([x, y]) => `radial-gradient(circle 240px at ${x}px ${y}px, rgba(255,255,255,0.35), rgba(212,175,55,0.18), transparent 80%)`);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    mouseX.set((e.clientX - rect.left) / rect.width - 0.5);
    mouseY.set((e.clientY - rect.top) / rect.height - 0.5);
    spotlightX.set(e.clientX - rect.left); spotlightY.set(e.clientY - rect.top);
  };

  return (
    <section id="about" className="relative w-screen min-h-screen bg-black text-[#E8DFD8] font-sans py-24 lg:py-32 px-6 sm:px-12 lg:px-20 overflow-hidden flex items-center">
      <motion.div animate={{ scale: [1, 1.2, 1], opacity: [0.08, 0.16, 0.08] }} transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }} className="absolute top-1/4 left-1/6 w-[32rem] h-[32rem] bg-[#D4AF37] rounded-full blur-[160px] pointer-events-none" />
      <motion.div animate={{ scale: [1.2, 1, 1.2], opacity: [0.05, 0.12, 0.05] }} transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }} className="absolute bottom-1/6 right-1/4 w-[28rem] h-[28rem] bg-[#8C6D4F] rounded-full blur-[170px] pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full relative z-10">
        <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.9 }} className="flex items-center space-x-4 mb-10">
          <span className="text-[11px] font-medium tracking-[0.35em] uppercase text-[#D4AF37]" style={{ fontFamily: "'Montserrat', sans-serif" }}>01 / ABOUT ME</span>
          <div className="w-20 h-[1px] bg-gradient-to-r from-[#D4AF37]/80 via-[#8C6D4F]/40 to-transparent" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          <motion.div variants={containerVariants} initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-100px' }} className="lg:col-span-7 flex flex-col justify-center">
            <motion.div variants={fadeUpVariants} className="relative mb-6 select-none">
              <h2 className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.4rem] tracking-tight uppercase leading-[0.88]" style={{ fontFamily: "'Bebas Neue', sans-serif" }}>
                <span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#FFFFFF] via-[#D5CBC0] to-[#605448]">LEARN BY BUILDING.</span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-b from-[#F7E7C4] via-[#C99E5D] to-[#543B1A]">BUILD WITH AI.</span>
              </h2>
            </motion.div>

            <motion.p variants={fadeUpVariants} className="text-xs sm:text-sm md:text-[14.5px] font-light text-[#B3A497] leading-[1.85] tracking-wide mb-10 max-w-xl" style={{ fontFamily: "'Montserrat', sans-serif" }}>
              I'm <span className="text-[#F3DBB3] font-medium">Ahmad</span>, a 17-year-old student and AI enthusiast from Pakistan. I build websites, apps, games and AI-powered experiments while learning modern development through real projects. My current work ranges from a personal voice assistant called Jarvis and study tools to native Android apps, interactive games and creative web experiences.
            </motion.p>

            <motion.div variants={fadeUpVariants} className="grid grid-cols-2 sm:grid-cols-4 gap-6 pt-6 pb-2 border-t border-[#8C6D4F]/25">
              {[
                ['17', 'YEARS OLD'],
                ['AI', 'CORE INTEREST'],
                ['WEB + APP', 'BUILDING'],
                ['20+', 'PUBLIC REPOS'],
              ].map(([value, label], i) => (
                <div key={label} className="flex flex-col">
                  <span className={`text-3xl sm:text-4xl font-light tracking-tight ${i === 1 || i === 3 ? 'text-[#D4AF37]' : 'text-[#F4EBE2]'}`} style={{ fontFamily: "'Bebas Neue', sans-serif" }}>{value}</span>
                  <span className="text-[10px] font-medium tracking-[0.22em] uppercase text-[#A8988B] mt-0.5">{label}</span>
                </div>
              ))}
            </motion.div>
          </motion.div>

          <div className="lg:col-span-5 flex items-center justify-center relative perspective-[1400px]">
            <motion.div animate={{ scale: isCardHovered ? 1.15 : 1, opacity: isCardHovered ? 0.35 : 0.15, rotate: isCardHovered ? 180 : 0 }} transition={{ duration: 3, ease: 'easeOut' }} className="absolute -inset-6 bg-[conic-gradient(from_0deg,#D4AF37_0%,#8C6D4F_30%,transparent_60%,#D4AF37_100%)] blur-2xl rounded-3xl pointer-events-none" />
            <motion.div ref={cardRef} onMouseMove={handleMouseMove} onMouseEnter={() => setIsCardHovered(true)} onMouseLeave={() => { setIsCardHovered(false); mouseX.set(0); mouseY.set(0); }} style={{ rotateX, rotateY }} transition={{ type: 'spring', stiffness: 120, damping: 20 }} className="relative group w-full max-w-[430px] p-3 rounded-sm bg-[#0A0806] border border-[#8C6D4F]/50 shadow-[0_25px_70px_rgba(0,0,0,0.95)] transform-gpu">
              <div className="absolute inset-0 border border-[#D4AF37]/20 pointer-events-none" />
              <div className="relative overflow-hidden w-full aspect-[4/5] bg-black rounded-sm">
                <img src={aboutImg} alt="Ahmad" className="w-full h-full object-cover object-top filter brightness-[0.94] contrast-[1.06] saturate-[1.02] group-hover:brightness-105 group-hover:contrast-[1.12] transition-all duration-700" />
                <motion.div className="absolute inset-0 pointer-events-none mix-blend-overlay" style={{ background: spotlightBg, opacity: isCardHovered ? 1 : 0 }} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent pointer-events-none" />
                <div className="absolute bottom-4 left-4 z-20 select-none"><span className="text-xs tracking-[0.3em] uppercase text-[#F2D8A7]" style={{ fontFamily: "'Montserrat', sans-serif" }}>AHMAD • 17</span></div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
