# Ahmad — AI Enthusiast & Developer Portfolio

A cinematic React + TypeScript portfolio customized for Ahmad.

## Stack
- React + TypeScript
- Vite
- Tailwind CSS
- Framer Motion
- Lenis

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

The hero video is `public/videos/hero.mp4` and the profile image is `src/assets/about.png`.
